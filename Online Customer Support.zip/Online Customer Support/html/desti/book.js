

function myfunction(){
	varx=document.getElementById("myInput");
	vary=document.getElementById("hide1");
	varz=document.getElementById("hide2");
	
	if(x.type==="password"){
	x.type="text";
	y.style.dispaly="block";
	z.style.display="block";
	}

const seleced=document.querySelector("selected");
const optioncontainer=document.querySelector("option.container");

const optionList= document.querySelectorAll("option");

});

optionList.forEach(0 => {
	o.addEventListener("click",() => {
		selected.innerHTML= 0.queryselector("label").innerHTML;
		optioncontainer.classList.remove("action");
		
	});
	
});